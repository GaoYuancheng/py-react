// const methodsMap = {
//   'GET'
// }

// methodsMap = {
//   'GET': 'get'
// }