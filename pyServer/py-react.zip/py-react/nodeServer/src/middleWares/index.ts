export default [require('./resFormat')]
