import { ApplyPluginsType } from '/Users/gaoyuancheng/Desktop/git-reposity/py-react/frontend/node_modules/@umijs/runtime';
import { plugin } from './plugin';

const routes = [
  {
    "path": "/login",
    "component": require('@/pages/Login').default,
    "exact": true
  },
  {
    "path": "/",
    "component": require('@/layouts').default,
    "routes": [
      {
        "path": "/py/home",
        "component": require('@/pages/Home').default,
        "name": "name-home",
        "exact": true
      },
      {
        "path": "/py/zhihu",
        "component": require('@/pages/Zhihu').default,
        "name": "name-zhihu",
        "exact": true
      },
      {
        "path": "/py/toutiao",
        "component": require('@/pages/Toutiao').default,
        "name": "name-toutiao",
        "exact": true
      },
      {
        "path": "/py/upload",
        "component": require('@/pages/Upload').default,
        "name": "name-upload",
        "exact": true
      },
      {
        "path": "/node/test",
        "component": require('@/pages/Test').default,
        "name": "name-test",
        "exact": true
      }
    ]
  },
  {
    "path": "/*",
    "component": require('@/pages/NotFound').default,
    "exact": true
  }
];

// allow user to extend routes
plugin.applyPlugins({
  key: 'patchRoutes',
  type: ApplyPluginsType.event,
  args: { routes },
});

export { routes };
