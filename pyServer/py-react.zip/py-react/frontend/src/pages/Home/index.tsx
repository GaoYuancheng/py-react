import React from 'react';
import { Link } from 'umi';
import { Button } from 'antd';


export default () => {
  return (
    <div>
      home
    </div>
  );
};
