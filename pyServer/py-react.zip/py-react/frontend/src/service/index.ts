import * as zhihu from './zhihu'
import * as toutiao from './toutiao'
import * as upload from './upload'
import * as test from './test'
import * as login from './login'


export default {
  toutiao,
  zhihu,
  upload,
  test,
  login
}